import { useEffect, useRef} from "react"
import { useDispatch, useSelector } from "react-redux"
import CardUI from "../UI/Card/Card"
import useHttp from "../Utils/Http"
import { Splide, SplideSlide } from '@splidejs/react-splide';
import '@splidejs/react-splide/css';
import { postActions, slideActions } from "../Store/Store";
import { Button } from "@mui/material";


const Home = ()=>{

  const data = useSelector(state=>state.posty.posts)
  const slideDispatch =  useDispatch()
  const {fetchPosts} = useHttp()
  console.log(data)
  useEffect(()=>{
    fetchPosts()
  },[fetchPosts])


  const playRef = useRef();
  

const setAudioUrl = (post)=>{
    const audioUrl = (post?.data?.media?.reddit_video?.fallback_url);
    if(audioUrl){
        let splitAudioURl =audioUrl.split("_");
        return (splitAudioURl[0]).concat('_audio.mp4')
    }   
}
    const posts = data.map((post,index)=>{
        let audioURL = setAudioUrl(post)
        return (
            <SplideSlide key={index}>
          <CardUI ref={playRef} videourl={post?.data?.media?.reddit_video?.fallback_url} 
          title = {post?.data?.title}
          audioUrl = {audioURL}
          />
          </SplideSlide>
        )
      })
    return (
        <>

<Splide className="splide" aria-label="My Favorite Images"
options={ {
    rewind: true,
    width : 800,
    arrows:false,
    pagination:false,
    lazyLoad:true,
    direction:'ttb',
    perPage:1,
    heightRatio:1,
    height:'100vh',
    lazyLoad:true,
  } 
  }
  onActive={(splice,prev,next)=>{
    if(prev.slide?.children[0]?.children[1] && prev.slide?.children[0]?.children[2] ) {
      prev.slide?.children[0]?.children[1].play()
      prev.slide?.children[0]?.children[2].play()
    }
      
  }}
  onInactive={(splice,prev)=>{
    if(prev.slide?.children[0]?.children[1] && prev.slide?.children[0]?.children[2] ) {
      prev.slide?.children[0]?.children[1].pause()
    prev.slide?.children[0]?.children[2].pause()
    }  
  }}>
{posts}
<SplideSlide>
  <Button varient ="contained">Load More</Button>
</SplideSlide> 
  </Splide>
        </>
    )
}
export default Home;