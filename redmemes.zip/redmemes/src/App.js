import './App.css';
import Header from './UI/Header/header';
import Home from './Pages/Home';
function App() {
  return (
    <>
    <Header/>
    <Home/>
    </>
  );
}

export default App;
