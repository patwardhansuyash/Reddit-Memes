import { Button } from '@mui/material';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import React, { useRef } from 'react';

const CardUI = React.forwardRef((props,ref)=>{

  const videoRef1 = useRef()
  const videoRef2 = useRef()


  document.addEventListener("visibilitychange", onchange);
function onchange (evt) {
   videoRef1.current.pause();
   videoRef2.current.pause();
}

  return (
    <Card sx={{ maxWidth: '100%'}}>
      <div></div>
      {props.videourl && 
      <>
      <video ref={videoRef1} height="100%"  width="100%" loop>
    <source src= {props.videourl} type="video/mp4"/>
    </video>
    <video ref={videoRef2} controls loop>
    <source src= {props.audioUrl} type="video/mp4"/>
    </video>
      </>}
    </Card>
  );
})

export default CardUI;