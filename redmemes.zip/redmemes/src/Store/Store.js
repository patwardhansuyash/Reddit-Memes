import { configureStore, createSlice } from "@reduxjs/toolkit"

const initialPosts = {
    posts:[],
}

const initialSlide = {
    slideChanged:null
}

const postsSlice = createSlice( {
    name:'postSlice',
    initialState:initialPosts,
    reducers:{
        getPosts(state,action){ 
        state.posts = action.payload
        },
    }
})




const slideSlice = createSlice( {
    name:'postSlice',
    initialState:initialSlide,
    reducers:{
        changeSlide(state,action){ 
            state.slideChanged = action.payload
            },
    }
})


export const postActions = postsSlice.actions
export const slideActions = slideSlice.actions

const Store = configureStore({
    reducer:{posty:postsSlice.reducer,
    slidy:slideSlice.reducer}
})

export default Store;
