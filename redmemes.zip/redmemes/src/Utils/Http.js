import { useCallback } from "react";
import { useDispatch } from "react-redux";
import { postActions } from "../Store/Store";

const useHttp =()=>{
    const dispatchPosts = useDispatch()
    const fetchPosts = useCallback(async()=>{
        const response =  await fetch('https://www.reddit.com/r/IndianDankMemes.json')
        const posts = await response.json();
        dispatchPosts(postActions.getPosts(posts?.data?.children))  
        },[])
return {
    fetchPosts
}

}
export default useHttp;